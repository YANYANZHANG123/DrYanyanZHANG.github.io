---
title:          "APEX-Searcher: Augmenting LLMs' Search Capabilities through Agentic Planning and Execution"
date:           2026-03-14 00:01:00 +0800
selected:       true
pub:            "Conference on Empirical Methods in Natural Language Processing (EMNLP)"
pub_last:       ' <span class="badge badge-pill badge-publication badge-info">Findings</span>'
pub_date:       "2026"
abstract: >-
  We propose APEX-Searcher, a framework that augments LLMs' search capabilities through agentic planning and execution for improved information retrieval.
abstract_zh: >-
  我们提出了APEX-Searcher，一个通过智能体规划与执行来增强大语言模型搜索能力的框架，以改善信息检索效果。
authors:
  - Kun Chen
  - Qingchao Kong#
  - Feifei Zhao
  - Wenji Mao
cover:          /assets/images/covers/APEX.png
links: 
  arXiv: https://arxiv.org/abs/2603.13853
---
